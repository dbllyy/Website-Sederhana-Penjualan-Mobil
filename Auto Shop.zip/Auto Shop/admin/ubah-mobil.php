<?php 
include('header.php');
require('fungsi.php');

$id = $_GET["idmobil"];
$rows = query("SELECT * FROM mobil WHERE idmobil = $id")[0];
if (isset($_POST["submit"])) {
  if (ubah_mobil($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-mobil.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'ubah-mobil.php';
  </script>";
  }
}
?>

<style>
.card {
  color: white;
}
</style>
<div class="container">

  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5" style="background-color:orangered">
    <div class="card-body">
      <p style="font-size: 120% ;">Ubah Data Mobil</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="idmobil">Id Mobil</label>
              <input type="text" class="form-control" name="idmobil" placeholder="Masukan Id Mobil"
                value="<?= $rows["idmobil"] ?>">
            </div>
            <div class="form-group">
              <label for="merk">Nama Merk</label>
              <input type="text" class="form-control" name="merk" placeholder="Masukan Nama Mobil"
                value="<?= $rows["merk"] ?>">
            </div>
            <div class="form-group">
              <label for="harga">Harga</label>
              <input type="text" class="form-control" name="harga" placeholder="Masukan Harga Mobil"
                value="<?= $rows["harga"] ?>">
            </div>
            <div class="form-group">
              <label for="warna">Warna</label>
              <input type="text" class="form-control" name="warna" placeholder=" Masukan warna Mobil"
                value="<?= $rows["warna"] ?>">
            </div>

            <div class="form-group">
              <label for="tahunpembuatan">tahunpembuatan</label>
              <input type="text" class="form-control" name="tahunpembuatan" placeholder=" Masukan tahun pembuatan Mobil"
                value="<?= $rows["tahunpembuatan"] ?>">
            </div>

            <div class="form-group">
              <label for="pajakberakhir">Pajak Berakhir</label>
              <input type="text" class="form-control" name="pajakberakhir" placeholder=" Masukan pajak berakhir Mobil"
                value="<?= $rows["pajakberakhir"] ?>">
            </div>

            <div class="form-group">
              <label for="gambar">Gambar</label>
              <input type="text" class="form-control" name="gambar" placeholder="Contoh : mobil toyota.jpg"
                value="<?= $rows["gambar"] ?>">
            </div>

            <!-- <div class="form-group">
              <label for="terjual">Status (tersedia.jpg / soldout.jpg)</label>
              <input type="text" class="form-control" name="terjual" placeholder=" Masukan terjual Mobil"
                value="<?= $rows["terjual"] ?>">
            </div> -->
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-mobil.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>