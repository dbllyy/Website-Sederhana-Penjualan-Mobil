<?php
include('header.php');
require 'fungsi.php';

$id = $_GET["idpembeli"];
// $result = mysqli_query($db, 'SELECT * FROM mata_plajaran');
$rows = query("SELECT * FROM pembeli WHERE idpembeli = $id")[0];
if (isset($_POST["submit"])) {
    if (ubah_pembelian($_POST) > 0) {
        echo "
        <script>
            alert('Data berhasil diubah!');
            document.location.href = 'data-pembeli.php';
        </script>";
    } else {
        echo "
		<script>
			alert('Data gagal diubah!');
			document.location.href = 'ubah-pembeli.php';
		</script>";
    }
}
?>


<style>
.card {
  color: white;
}
</style>
<div class="container">

  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5" style="background-color:orangered">
    <div class="card-body">
      <p style="font-size: 120% ;">Ubah Data Pembeli</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="idpembeli">Id Pembeli</label>
              <input type="text" class="form-control" name="idpembeli" placeholder="Masukan Id Pembeli"
                value="<?= $rows["idpembeli"] ?>">
            </div>
            <div class="form-group">
              <label for="noktp">No KTP</label>
              <input type="text" class="form-control" name="noktp" placeholder="Masukan No KTP"
                value="<?= $rows["noktp"] ?>">
            </div>
            <div class="form-group">
              <label for="nama">Nama Pembeli</label>
              <input type="text" class="form-control" name="nama" placeholder="Masukan Nama Pembeli"
                value="<?= $rows["nama"] ?>">
            </div>
            <div class="form-group">
              <label for="ttl">Tempat Tanggal Lahir</label>
              <input type="text" class="form-control" name="ttl" placeholder="Masukan Tempat Tanggal Lahir Pembeli"
                value="<?= $rows["ttl"] ?>">
            </div>
            <div class="form-group">
              <label for="gender">Jenis Kelamin</label>
              <input type="gender" class="form-control" name="gender" placeholder=" Masukan Jenis Kelamin Pembeli"
                value="<?= $rows["gender"] ?>">
            </div>

            <div class="form-group">
              <label for="alamat">Alamat</label>
              <input type="alamat" class="form-control" name="alamat" placeholder=" Masukan Jenis Kelamin Pembeli"
                value="<?= $rows["alamat"] ?>">
            </div>

            <div class="form-group">
              <label for="nohp">No HP</label>
              <input type="nohp" class="form-control" name="nohp" placeholder=" Masukan Jenis Kelamin Pembeli"
                value="<?= $rows["nohp"] ?>">
            </div>


            <div class="form-group">
              <label for="pembayaran">Pembayaran</label>
              <input type="pembayaran" class="form-control" name="pembayaran" placeholder=" Masukan Pembayaran Pembeli"
                value="<?= $rows["pembayaran"] ?>">
            </div>

            <div class="form-group">
              <label for="idmobil">idmobil</label>
              <input type="idmobil" class="form-control" name="idmobil" placeholder=" Masukan idmobil Pembeli"
                value="<?= $rows["idmobil"] ?>">
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-pembeli.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>