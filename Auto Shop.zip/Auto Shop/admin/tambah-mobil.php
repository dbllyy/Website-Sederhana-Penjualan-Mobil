<?php 
include('header.php');
require('fungsi.php');

$rows = query("SELECT * FROM mobil")[0];
if (isset($_POST["submit"])) {
  if (tambah_mobil($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-mobil.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'tambah-mobil.php';
  </script>";
  }
}
?>

<?php
include("../koneksi.php");
$data = mysqli_query($connection, "SELECT max((idmobil) + 1) as id_ad FROM mobil");
$row = mysqli_fetch_array($data);
?>
<style>
.card {
  color: white;
}
</style>
<div class="container">

  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5" style="background-color:orangered">
    <div class="card-body">
      <p style="font-size: 120% ;">Tambah Data Mobil</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="idmobil">Id Mobil</label>
              <input type="text" class="form-control" name="idmobil" placeholder="Masukan Id Mobil"
                value="<?php echo $row['id_ad']; ?>">
            </div>
            <div class="form-group">
              <label for="merk">Nama Merk</label>
              <input type="text" class="form-control" name="merk" placeholder="Masukan Nama Mobil" required>
            </div>
            <div class="form-group">
              <label for="harga">Harga</label>
              <input type="text" class="form-control" name="harga" placeholder="Masukan Harga Mobil" required>
            </div>
            <div class="form-group">
              <label for="warna">Warna</label>
              <input type="text" class="form-control" name="warna" placeholder=" Masukan warna Mobil" required>
            </div>

            <div class="form-group">
              <label for="tahunpembuatan">Tahun Pembuatan</label>
              <input type="text" class="form-control" name="tahunpembuatan" placeholder=" Masukan tahun pembuatan Mobil"
                required>
            </div>

            <div class="form-group">
              <label for="pajakberakhir">Pajak Berakhir</label>
              <input type="text" class="form-control" name="pajakberakhir" placeholder=" Masukan pajak berakhir Mobil"
                required>
            </div>

            <div class="form-group">
              <!-- MASIH PENGEMBANGAN BANG NTAR BISA PERBAIKAN LAGI -->
              <label for="gambar">Gambar(Gambar harus ada didalam /assets/img/)</label>
              <input type="text" class="form-control" name="gambar" placeholder="Contoh : mobil toyota.jpg" required>
            </div>

            <div class="form-group">
              <label for="terjual">Status</label>
              <input type="text" class="form-control" name="terjual" placeholder=" Masukan terjual Mobil"
                value="tersedia.jpg">
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-mobil.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>