<?php 
include('header.php');
require('fungsi.php');

if (isset($_POST["submit"])) {
  if (tambah_pembelian($_POST) > 0) {

      echo "
      <script>
          alert('Data berhasil ditambahkan!');
          document.location.href = 'data-pembeli.php';
      </script>";
  } else {
      echo "
  <script>
    alert('Data gagal ditambahkan!');
    document.location.href = 'tambah-pembeli.php';
  </script>";
  }
}
?>

<?php
include("../koneksi.php");
$data = mysqli_query($connection, "SELECT max((idpembeli) + 1) as id_ad FROM pembeli");
$row = mysqli_fetch_array($data);
?>

<style>
.card {
  color: white;
}
</style>
<div class="container">

  <div style="margin-top: 5rem;"></div>
  <div class="card mt-5" style="background-color:orangered">
    <div class="card-body">
      <p style="font-size: 120% ;">Tambah Data Pembeli</p>
      <br>
      <div class=col-6>
        <form method="POST">
          <table>
            <div class="form-group">
              <label for="idpembeli">Id Pembeli</label>
              <input type="text" class="form-control" name="idpembeli" placeholder="Masukan Id Pembeli"
                value="<?php echo $row['id_ad']; ?>">
            </div>
            <div class="form-group">
              <label for="noktp">No KTP</label>
              <input type="text" class="form-control" name="noktp" placeholder="Masukan No KTP" required>
            </div>
            <div class="form-group">
              <label for="nama">Nama Pembeli</label>
              <input type="text" class="form-control" name="nama" placeholder="Masukan Nama Pembeli" required>
            </div>
            <div class="form-group">
              <label for="ttl">Tempat Tanggal Lahir</label>
              <input type="text" class="form-control" name="ttl" placeholder="Masukan Tempat Tanggal Lahir Pembeli"
                required>
            </div>

            <div class="form-group">
              <label for="gender">Jenis Kelamin</label>
              <select name="gender" id="gender" class="form-control">
                <option value="Laki-Laki">Laki-Laki</option>
                <option value="Perempuan">Perempuan</option>
              </select>
            </div>

            <div class="form-group">
              <label for="alamat">Alamat</label>
              <input type="alamat" class="form-control" name="alamat" placeholder=" Masukan Jenis Kelamin Pembeli"
                required>
            </div>

            <div class="form-group">
              <label for="nohp">No HP</label>
              <input type="nohp" class="form-control" name="nohp" placeholder=" Masukan Jenis Kelamin Pembeli" required>
            </div>

            <div class="form-group">
              <label for="pembayaran">Pembayaran</label>
              <select name="pembayaran" id="pembayaran" class="form-control">
                <option value="Cash">Cash</option>
                <option value="Kredit">Kredit</option>
                <option value="Debit">Debit</option>
              </select>
            </div>

            <div class="form-group">
              <label for="idmobil">idmobil</label>
              <select name="idmobil" id="idmobil" class="form-control">
                <option value="">Pilih Mobil</option>
                <?php $row_kost = mysqli_query($connection, "SELECT * FROM tampilkan_data_mobil");
                                            while ($row = mysqli_fetch_array($row_kost)) {
                                                echo "<option value='$row[idmobil]'>$row[merk]</option>";
                                                $jumlah_tersedia = $row['idmobil'];
                                            }
                                            mysqli_free_result($row_kost); // untuk penggunaan multiple prosedur
                                            mysqli_next_result($connection);
                                            ?>
              </select>
            </div>
          </table>

          <button type="submit" name="submit" class="btn btn-primary"><span><i
                class="fa fa-user-plus"></i>Submit</button>
          <a href="data-pembeli.php" onclick=" return confirm ('Apakah anda ingin membatal data ini?');"><button
              type="button" class="btn btn-danger">
              <span><i class="fa fa-pencil-square-o"></i> Batal</button></span></a>
          <hr>
        </form>
      </div>
    </div>
  </div>
</div>
<?php 
include('footer.php');
?>