<?php 
include('../koneksi.php');


function query($query)
{
    global $connection;
    $result = mysqli_query($connection, $query);
    $rows = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $rows[] = $row;
    }
    return $rows;
}

function tambah_admin($data)
{
  global $connection;
  $id_admin = htmlspecialchars($data["id_admin"]);
  $nama_admin = htmlspecialchars($data["namauser"]);
  $username = htmlspecialchars($data["username"]);
  $password = htmlspecialchars($data["password"]);

  $query = "INSERT INTO user VALUES ('$id_admin','$nama_admin','$username','$password')";
  mysqli_query($connection, $query);
  return mysqli_affected_rows($connection);
}
function hapus_admin($id)
{
  global $connection;
  mysqli_query($connection, "DELETE FROM user WHERE iduser = $id");
  return mysqli_affected_rows($connection);
}


function ubah_admin($data)
{
  global $connection;
  $id_admin = htmlspecialchars($data["iduser"]);
  $nama_admin = htmlspecialchars($data["namauser"]);
  $username = htmlspecialchars($data["username"]);
  $password = htmlspecialchars($data["password"]);

    $query = "UPDATE user SET 
             namauser ='$nama_admin',
             username ='$username',
             password ='$password'
             WHERE iduser = $id_admin
             ";
    mysqli_query($connection, $query);
    return mysqli_affected_rows($connection);
}


function hapus_pembeli($id)
{
  global $connection;
  mysqli_query($connection, "DELETE FROM pembeli WHERE idpembeli = $id");
  return mysqli_affected_rows($connection);
}

function tambah_pembeli($data)
{
  global $connection;
  $idpembeli = htmlspecialchars($data["idpembeli"]);
  $noktp = htmlspecialchars($data["noktp"]);
  $nama = htmlspecialchars($data["nama"]);
  $ttl = htmlspecialchars($data["ttl"]);
  $gender = htmlspecialchars($data["gender"]);
  $alamat = htmlspecialchars($data["alamat"]);
  $nohp = htmlspecialchars($data["nohp"]);
  $pembayaran = htmlspecialchars($data["pembayaran"]);
  $idmobil = htmlspecialchars($data["idmobil"]);
  $query = "CALL insertpembeli('$idpembeli','$noktp','$nama','$ttl','$gender','$alamat','$nohp','$pembayaran','$idmobil')";
  mysqli_query($connection, $query);
  return mysqli_affected_rows($connection);
}




function tambah_pembelian ($data)
{
  global $connection;
  $idpembeli = htmlspecialchars($data["idpembeli"]);
  $noktp = htmlspecialchars($data["noktp"]);
  $nama = htmlspecialchars($data["nama"]);
  $ttl = htmlspecialchars($data["ttl"]);
  $gender = htmlspecialchars($data["gender"]);
  $alamat = htmlspecialchars($data["alamat"]);
  $nohp = htmlspecialchars($data["nohp"]);
  $pembayaran = htmlspecialchars($data["pembayaran"]);
  $idmobil = htmlspecialchars($data["idmobil"]);
  
  $query = "INSERT INTO pembeli VALUES ('$idpembeli','$noktp','$nama','$ttl','$gender','$alamat','$nohp','$pembayaran','$idmobil')";
  mysqli_query($connection, $query);
  return mysqli_affected_rows($connection);
}

function ubah_pembelian($data)
{
  global $connection;
  $idpembeli = htmlspecialchars($data["idpembeli"]);
  $noktp = htmlspecialchars($data["noktp"]);
  $nama = htmlspecialchars($data["nama"]);
  $ttl = htmlspecialchars($data["ttl"]);
  $gender = htmlspecialchars($data["gender"]);
  $alamat = htmlspecialchars($data["alamat"]);
  $nohp = htmlspecialchars($data["nohp"]);
  $pembayaran = htmlspecialchars($data["pembayaran"]);
  $idmobil = htmlspecialchars($data["idmobil"]);

  $query = "UPDATE pembeli SET 
  idpembeli ='$idpembeli',
  noktp ='$noktp',
  nama ='$nama',
  ttl  ='$ttl ',
  gender  ='$gender ',
  alamat ='$alamat',
  nohp  ='$nohp',
  pembayaran  ='$pembayaran',  
  idmobil  ='$idmobil'
  WHERE idpembeli = $idpembeli
  ";
mysqli_query($connection, $query);
return mysqli_affected_rows($connection);
}

function tambah_mobil ($data)
{
  global $connection;
  $idmobil = htmlspecialchars($data["idmobil"]);
  $merk = htmlspecialchars($data["merk"]);
  $harga = htmlspecialchars($data["harga"]);
  $warna = htmlspecialchars($data["warna"]);
  $tahunpembuatan = htmlspecialchars($data["tahunpembuatan"]);
  $pajakberakhir = htmlspecialchars($data["pajakberakhir"]);
  $statuspajak = htmlspecialchars($data["statuspajak"]);
  $gambar = htmlspecialchars($data["gambar"]);
  $terjual = htmlspecialchars($data["terjual"]);
  
  $query = "CALL insertmobil ('$idmobil','$merk','$harga','$warna','$tahunpembuatan','$pajakberakhir','$gambar','$terjual')";
  mysqli_query($connection, $query);
  return mysqli_affected_rows($connection);
}

function ubah_mobil($data)
{
  global $connection;
  $idmobil = htmlspecialchars($data["idmobil"]);
  $merk = htmlspecialchars($data["merk"]);
  $harga = htmlspecialchars($data["harga"]);
  $warna = htmlspecialchars($data["warna"]);
  $tahunpembuatan = htmlspecialchars($data["tahunpembuatan"]);
  $pajakberakhir = htmlspecialchars($data["pajakberakhir"]);
  // $statuspajak = htmlspecialchars($data["statuspajak"]);
  $gambar = htmlspecialchars($data["gambar"]);
  // $terjual = htmlspecialchars($data["terjual"]);

  $query = "CALL updatemobil('$idmobil','$merk','$harga','$warna','$tahunpembuatan','$pajakberakhir','$gambar')";
mysqli_query($connection, $query);
return mysqli_affected_rows($connection);
}

function hapus_mobil($id)
{
  global $connection;
  mysqli_query($connection, "DELETE FROM mobil WHERE idmobil = $id");
  return mysqli_affected_rows($connection);
}

function hapus_detail($id)
{
  global $connection;
  mysqli_query($connection, "DELETE FROM detailbeli WHERE idbeli = $id");
  return mysqli_affected_rows($connection);
}
?>